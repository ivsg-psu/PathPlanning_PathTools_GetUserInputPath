# PathPlanning_PathTools_GetUserInputPath
A function for the user to click on the figure to generate XY path until the user hits the "return" key.
