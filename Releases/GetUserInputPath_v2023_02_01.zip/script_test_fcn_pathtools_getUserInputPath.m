% script_test_fcn_pathtools_getUserInputPath
% This is a script to exercise the function:
% fcn_pathtools_getUserInputPath.m
% This function was written on 2020_10_15 by S. Brennan
% Questions or comments? sbrennan@psu.edu 

close all;

%% BASIC example 1
fig_num = 1;
pathXY = fcn_pathtools_getUserInputPath(fig_num);

